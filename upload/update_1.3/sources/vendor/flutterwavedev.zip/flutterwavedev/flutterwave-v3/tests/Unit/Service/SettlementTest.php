<?php

namespace Unit\Service;

use Flutterwave\Service\Settlement;
use PHPUnit\Framework\TestCase;

class SettlementTest extends TestCase
{
//    public function testRetrievingAllSettlement()
//    {
//        $service = new Settlement();
//        $response = $service->list();
//        $this->assertTrue(property_exists($response,'data') && \is_array($response->data));
//    }
//
//    public function testRetrievingASettlement()
//    {
//        $service = new Settlement();
//        $response = $service->get("41748");
//        $this->assertTrue(property_exists($response,'data') && isset($response->data->status));
//    }
}