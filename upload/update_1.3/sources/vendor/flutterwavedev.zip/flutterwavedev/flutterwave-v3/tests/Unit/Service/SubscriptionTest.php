<?php

namespace Unit\Service;

use Flutterwave\Service\Subscription;
use PHPUnit\Framework\TestCase;

class SubscriptionTest extends TestCase
{
//    public function testRetrievingAllSubs()
//    {
//        $service = new Subscription();
//        $response = $service->list();
//        $this->assertTrue(property_exists($response,'data') && \is_array($response->data));
//    }
//
//    public function testActivatingSubscriptions()
//    {
//        $service = new Subscription();
//        $response = $service->activate("4147");
//        $this->assertTrue($response->message === "Subscription activated");
//    }
}