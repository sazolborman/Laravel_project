<?php

declare(strict_types=1);

return [
    'AIRTIME',
    'DSTV',
    'DSTV BOX OFFICE',
    'Postpaid',
    'Prepaid',
    'AIRTEL',
    'IKEDC TOP UP',
    'EKEDC POSTPAID TOPUP',
    'EKEDC PREPAID TOPUP',
    'LCC',
    'KADUNA TOP UP',
];
