<?php

declare(strict_types=1);

namespace Flutterwave\Exception;

class ApiException extends \Unirest\Exception
{
}
