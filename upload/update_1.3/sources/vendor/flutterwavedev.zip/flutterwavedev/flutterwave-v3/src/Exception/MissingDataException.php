<?php

declare(strict_types=1);

namespace Flutterwave\Exception;

class MissingDataException extends \Exception
{
}
