<?php
echo "Playground";
echo "This is an implementation using the new Flutterwave PHP SDK.";