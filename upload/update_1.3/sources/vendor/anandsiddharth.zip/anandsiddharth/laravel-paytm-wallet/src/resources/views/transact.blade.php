<html>
<head>
<title>Merchant Check Out Page</title>
</head>
<body>
	<br>
	<br>
	<center><h1>Your transaction is being processed!!!</h1></center>
	<center><h2>Please do not refresh this page...</h2></center>
	@yield('payment_redirect')
</body>
</html>